package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CTS_NewCustomer")
public class NewCustomer extends Customer{
	
	

}
